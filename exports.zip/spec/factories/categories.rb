FactoryBot.define do
  factory :category do
    name { 'MyString' }
  end
end
